import Ipods from '../../../images/Eccomerce/ElectronicsPage/Products/Rectangle 69.png';

export const ElectronicsData = Array.from({ length: 100 }, (_, index) => ({
    id: index + 1,
    img: Ipods,
    name: 'Apple Air pods Pro',
    description: 'Lorem ipsum dolor sit amet consectetur. Consequat porttitor in porttitor id feugiat condimentum.',
    price: '₹25999/-',
    deliveryDate: 'FREE delivery Fri, 20 Sept',
}));
