import React from 'react'

const ElectronicsContent = () => {
  return (
    <div className='w-[1104px]  mt-[25px]'>
        <h1 class="text-[var(--Schemes-On-Primary)] mb-[6px] font-open-sans text-2xl font-bold leading-normal text-white">Electronics </h1>
        <p  class="text-[var(--Schemes-On-Primary)] text-justify font-open-sans text-sm font-semibold leading-normal text-white">Lorem ipsum dolor sit amet consectetur. Placerat eget tristique odio leo mi at fermentum at. Mi mollis sed pretium auctor. Arcu interdum purus justo urna. At sed mollis luctus tempus nunc eu.Lorem ipsum dolor sit amet consectetur. Placerat eget tristique odio leo mi at fermentum at. Mi mollis sed pretium auctor. Arcu interdum purus justo urna. At sed mollis luctus tempus nunc eu.Lorem ipsum dolor sit amet consectetur. Placerat eget tristique odio leo mi at fermentum at. Mi mollis sed pretium auctor. Arcu interdum purus justo urna. At sed mollis luctus tempus nunc eu.</p>
    </div>
  )
}

export default ElectronicsContent