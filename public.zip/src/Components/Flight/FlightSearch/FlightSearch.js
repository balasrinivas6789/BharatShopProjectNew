import React from 'react'

const FlightSearch = () => {
  return (
    <div>
        
    </div>
  )
}

export default FlightSearch