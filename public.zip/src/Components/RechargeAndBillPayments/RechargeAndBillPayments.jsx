import React from 'react'

const RechargeAndBillPayments = () => {
  return (
    <div >
        <h2 className='text-[#FF6D00] font-open-sans text-[32px] font-bold leading-none'>Recharge And Bill Payments</h2>

    </div>
  )
}

export default RechargeAndBillPayments